=== Magix Text Pro ===
Contributors: LUXMED
Donate link: https://luxmedprotez.com
Tags: animasyon, text animation, rotating text, seo text
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Sabit yazılarınıza güzel dönen metinler ekleyerek sitenize dinamik bir görünüm kazandırın.

== Description ==

Magix Text Pro, sitenize kolayca ekleyebileceğiniz dinamik metin animasyonları oluşturmanıza olanak tanır. Sabit bir yazı ile birlikte dönen değişken metinler oluşturabilir ve sitenizin herhangi bir yerinde gösterebilirsiniz.

Özellikler:

* Sabit metinlerle birlikte maksimum 5 adet dönen metin oluşturma
* Her bir metin için renk seçenekleri
* Metin boyutu ve kalınlık ayarları
* Kolay kullanımlı shortcode sistemi
* Canlı önizleme imkanı
* Modern ve şık admin arayüzü
* Son ek ekleme imkanı

== Installation ==

1. Eklenti dosyalarını `/wp-content/plugins/magix-text-pro` dizinine yükleyin
2. WordPress admin panelinden "Eklentiler" menüsünü açın
3. Eklentiler listesinden "Magix Text Pro" eklentisini aktifleştirin
4. Sol menüden "Magix Text Pro" sekmesine tıklayın ve kullanmaya başlayın

== Frequently Asked Questions ==

= Nasıl bir Magix Text oluşturabilirim? =

Admin panelinde "Magix Text Pro" menüsünden "Yeni Ekle" sekmesine tıklayın. Sabit metni ve dönen metinleri girin, renk ve biçimlendirme seçeneklerini ayarlayın, kaydedin. Oluşturulan shortcode'u sitenizin herhangi bir yerine ekleyin.

= En fazla kaç dönen metin ekleyebilirim? =

Her bir Magix Text için en fazla 5 adet dönen metin ekleyebilirsiniz.

= Shortcode'u nereye ekleyebilirim? =

Shortcode'u sayfa içerikleri, yazı içerikleri, widgetlar gibi shortcode destekleyen her yere ekleyebilirsiniz.

== Screenshots ==

1. Admin panel
2. Magix Text ekleme/düzenleme formu
3. Ön yüzde görünüm

== Changelog ==

= 1.0.0 =
* İlk sürüm

== Upgrade Notice ==

= 1.0.0 =
İlk sürümü yükleyin ve kullanmaya başlayın! 